# Framerate Vigilante

Required: [plugin-sdk](https://github.com/DK22Pac/plugin-sdk)

