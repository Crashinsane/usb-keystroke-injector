export { App as default } from './src/App';
