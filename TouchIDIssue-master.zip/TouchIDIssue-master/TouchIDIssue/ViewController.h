//
//  ViewController.h
//  TouchIDIssue
//
//  Created by liuge on 11/23/14.
//  Copyright (c) 2014 iLegendSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

