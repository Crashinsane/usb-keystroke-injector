package com.redmadrobot.flipper.support

import com.redmadrobot.flipper.Feature


object TestFeature : Feature() {
    override val id = "Test feature"
}
