package com.redmadrobot.flipper

@Suppress("UnnecessaryAbstractClass")
abstract class Feature {
    abstract val id: String
}
