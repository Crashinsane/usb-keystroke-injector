package com.redmadrobot.sample

import com.redmadrobot.flipper.Feature

object Features {

    object Feature1 : Feature() {
        override val id = "Feature1"
    }

    object Feature2 : Feature() {
        override val id = "Feature2"
    }

    object Feature3 : Feature() {
        override val id = "Feature3"
    }

    object Feature4 : Feature() {
        override val id = "Feature4"
    }
}
