object LibraryDependencies {
    object Firebase {
        private const val version = "20.0.1"

        const val firebaseConfig = "com.google.firebase:firebase-config:$version"
    }
}
