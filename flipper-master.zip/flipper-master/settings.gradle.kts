include(":flipper")
include(":flipper-firebase-config")
include(":app")

rootProject.name = "Flipper"
