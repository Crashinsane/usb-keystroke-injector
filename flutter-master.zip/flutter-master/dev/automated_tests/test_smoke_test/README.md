This directory is used by //flutter/dev/bots/test.dart to verify that
`flutter test` actually correctly fails when a test fails.
