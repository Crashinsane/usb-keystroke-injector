# platform_channels_benchmarks

The harness for running performance benchmark tests for Platform Channels.

If you want to run these benchmarks outside of devicelab you need to first run:
`flutter create --platforms="ios,android" --no-overwrite .`
