# rib-router-navigator

A utility for handling multiple mutually exclusive child routers. These module is by no means a
mandatory part of the RIB framework.
