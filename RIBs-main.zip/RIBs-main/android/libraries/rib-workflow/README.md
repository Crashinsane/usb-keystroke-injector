# rib-workflow

Deeplinking framework that represents each deeplink as a workflow of reactive steps. See tutorial 4.
