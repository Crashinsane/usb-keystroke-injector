# rib-base

This module is responsible for defining base rib components.
