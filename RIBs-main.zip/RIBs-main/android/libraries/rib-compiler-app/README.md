# rib-compiler

Base library for writing RIB annotation processors.
