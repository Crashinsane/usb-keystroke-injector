# RIBs Plugin for Flipper Debugging tool

This folder contains the desktop javascript plugin to be used with Flipper-enabled applications.

For setup and local development instructions, please see the Flipper official documentation for [loading custom plugins](https://fbflipper.com/docs/extending/loading-custom-plugins), using plugins path value of ```<path_to_repo>/android/tooling/rib-flipper-plugin/```.
