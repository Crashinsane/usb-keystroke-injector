# RIBs Plugin for Flipper Debugging tool

We have created a Flipper plugin to help visualize your application RIBs tree in realtime.

For details on installation and usage, please see the [RIBs Flipper Plugin documentation section](https://github.com/uber/RIBs/wiki/Android-Tooling#ribs-flipper-plugin-for-android) on the [Android tooling wiki page](https://github.com/uber/RIBs/wiki/Android-Tooling).
