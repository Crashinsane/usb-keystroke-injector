# Intellij Broadcast Core Debugging tool

This Android library implements support for exposing RIB tree via IntelliJ Debugging broadcast receiver.
