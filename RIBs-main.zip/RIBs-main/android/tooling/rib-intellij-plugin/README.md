# RIBs Code Generation Plugin for Android Studio and IntelliJ

We have created an Android Studio / IntelliJ plugin to generate RIBs scaffolding, making RIB usage and adoption easier.

For details on installation and usage, please see the [RIBs Code Generation Plugin documentation section](https://github.com/uber/RIBs/wiki/Android-Tooling#ribs-code-generation-plugin-for-android-studio-and-intellij) on the [Android tooling wiki page](https://github.com/uber/RIBs/wiki/Android-Tooling).
