The RIBs Workers Demo app showcases:

1. Binding of [com.uber.rib.core.Worker] with different [CoroutineContext]
2. Binding of [com.uber.rib.core.RibCoroutineWorker]
3. Binding multiple [com.uber.rib.core.Worker] in specific [CoroutineContext]
4. Convert existing [com.uber.rib.core.Worker] to [com.uber.rib.core.RibCoroutineWorker] and viceversa
