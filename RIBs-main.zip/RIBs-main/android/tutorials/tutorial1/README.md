# RIB Tutorial 1: Create a RIB

This project is the starting point for [tutorial 1](https://github.com/uber/RIBs/wiki/Android-Tutorial-1) that will get you aquatinted with the RIBs architecture.


### Getting started
Run the code by

```
./gradlew :tutorials:tutorial1:installDebug
```

Then follow the steps described in [tutorial 1](https://github.com/uber/RIBs/wiki/Android-Tutorial-1) on the RIBs wiki.
