# RIB Tutorial 2: Composing RIBs to create features

This project is the completed code for [tutorial 1](https://github.com/uber/RIBs/wiki/Android-Tutorial-1) and the starting point for [tutorial 2](https://github.com/uber/RIBs/wiki/Android-Tutorial-2).

### Getting started
Run the code by

```
./gradlew :tutorials:tutorial2:installDebug
```

Then follow the steps described in [tutorial 2](https://github.com/uber/RIBs/wiki/Android-Tutorial-2) on the RIBs wiki.
