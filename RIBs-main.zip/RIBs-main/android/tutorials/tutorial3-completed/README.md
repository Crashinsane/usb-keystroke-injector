# RIB Tutorial 3: RIB DI and communication

This project is the completed code for [tutorial 3](https://github.com/uber/RIBs/wiki/Android-Tutorial-3).

### Getting started
Run the code by

```
./gradlew :tutorials:tutorial3-completed:installDebug
```
