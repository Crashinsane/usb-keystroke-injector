# SAM-Auto
SAM Auto Steam Archievement Unlocker

Auto unlocking achievements made easy with Steam.

> **I am not the owner or programmer of this application, I reached and shared it during my backups. I and Github are not responsible for any damages that may arise from this sharing. After downloading, all responsibility belongs to the user!**

How to use?
 - Open the Steam app
 - Start the SAM Picker program
 - Click unlock all button
 - Wait for unlocking

> ***Before you open all the locks, be aware that it may cause problems with your computer! Close other apps running in the background and leave only two apps open***

![SAM Auto](https://raw.githubusercontent.com/oxcakmak/SAM-Auto/main/Screenshot_1.jpg)

Virus Total's:

[SAM-Auto.zip](https://www.virustotal.com/gui/file/be2321983a329b62b7ed7bb937ec523c2b05f4517603866a982c47b4087cc5db)

[SAM.API.dll](https://www.virustotal.com/gui/file/40f480715671d053bc89cd27cd05bc8117f0229c4bfab210e611d77f026e5bc1)

[SAM.Game.exe](https://www.virustotal.com/gui/file/a63b456350af981cc8b2cc5734289264d1b82b75974b307df3a87504d5081f86)

[SAM.Picker.exe](https://www.virustotal.com/gui/file/c4f10c4669b1c64353d84a98a9f64c340104e603ca4f2122cb6e34cce53f0727)
