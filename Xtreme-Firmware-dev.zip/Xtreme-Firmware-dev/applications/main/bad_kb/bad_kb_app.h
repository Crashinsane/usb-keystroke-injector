#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct BadKbApp BadKbApp;

#ifdef __cplusplus
}
#endif
