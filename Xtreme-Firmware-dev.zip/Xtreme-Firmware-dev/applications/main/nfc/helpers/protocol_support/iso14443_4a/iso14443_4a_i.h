#pragma once

#include <nfc/protocols/iso14443_4a/iso14443_4a.h>

#include "iso14443_4a.h"

NfcCommand nfc_scene_emulate_listener_callback_iso14443_4a(NfcGenericEvent event, void* context);
