**2022-02-20**:
* Verify string is not NULL before executing strlen when retrieving user's trusted device file [#73]
**2022-02-12:**
* Resolve bufferoverflow when trying to retrieve the user's trusted device file [#72]
    * Details: [Blog](https://zakuarbor.github.io/blog/bufoverflow/)
**2021-12-26:**
* Resolve symlink attack to gain access to another user's account [#47]
    * Details: [Blog](https://zakuarbor.github.io/blog/link-attack)

