# ACKNOWLEDGEMENTS
**[Simple PAM](https://github.com/beatgammit/simple-pam):** - Helped us learn how to work with PAM

**[Albert Huang](https://people.csail.mit.edu/albert/bluez-intro/):** for his documentation on working with Bluetooth on Linux. Documentation on Bluetooth is hard to find so we really appreciate Albert's work.

**[Ryan Scott](https://github.com/RyanGlScott/BluetoothTest):** I have based the starter code of the bluetooth server from his work.
