---
name: User Task
about: For Git Issues that intends to resolve or add a feature
title: ''
labels: ''
assignees: ''

---

## Purpose
*Detail what this issue is about. It can be a user story statement or a problem you wish to resolve*

## Tasks/Goals
- [ ] Break the issue into smaller tasks how you will approach the problem

## Summary
*To fill out once the issue is to be closed. Give a short summary of the changes you made to implement or fix an issue*
